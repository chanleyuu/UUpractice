#include <iostream>
#include <random>
#include <vector>

using namespace std;

int genrand(int min, int max);
void PopulateVector(vector <int> &v, int size);
void BottomUpMergeSort(vector<int> &array);
int search(vector<int> &array, int l, int r, int key);
void checkcopy(vector<int> &array1, vector<int> &array2);

int main(int argc, char **argv) {
    vector<int> v1;
    vector<int> v2;
    cout << "Capacity: " << v1.capacity() << " Size: " << v1.size() << endl;
    cout << "Capacity: " << v2.capacity() << " Size: " << v2.size() << endl;
   
    PopulateVector(v1, 100);
    PopulateVector(v2, 100);
    
    v1.shrink_to_fit();
    v2.shrink_to_fit();
    
    cout << "Capacity: " << v1.capacity() << " Size: " << v1.size() << endl;
    cout << "Capacity: " << v2.capacity() << " Size: " << v2.size() << endl;
    std::cout << "Hello, world!" << std::endl;
    
    BottomUpMergeSort(v1);
    BottomUpMergeSort(v2);
    checkcopy(v1, v2);
   // int s = search(v1, 0, v1.size(), 567);

    for (int i = 0; i < v1.size(); i++) {
        cout << v1[i] << " " << v2[i] << endl;
    }
    /*
    if (s > 0) {
        cout << "Key found at: " << s << endl;
    } 
    else {
        cout << "Key not found" << endl;
    }  */
    return 0;
}

int genrand(int min, int max) {
	std::random_device r;
	std::seed_seq seed2{ r(), r(), r(), r(), r(), r(), r(), r() };
	std::mt19937 eng(seed2);
	std::uniform_real_distribution<float> dist(min, max);
	return dist(eng);
}

void PopulateVector(vector <int> &v, int size) {
    for (int i = 0; i < size; i++) {
        v.push_back(genrand(0, 1000));
    }
}


void BottomUpMergeSort(vector<int> &array)
{
    int n = array.size();
    int B[n];
    for (int width = 1; width < n; width = 2 * width)
    {

        for (int i = 0; i < n; i = i + 2 * width)
        {
            //Bottom-Up Merge
            int iLeft = i;
            int iRight = min(i+width, n);
            int iEnd = min(i+2*width, n);
            int in = iLeft, j = iRight;
            // While there are elements in the left or right runs...
            for (int k = iLeft; k < iEnd; k++) {
                // If left run head exists and is <= existing right run head.
                if (in < iRight && (j >= iEnd || array[in] <= array[j])) {
                    B[k] = array[in];
                    in = in + 1;
                } else {
                    B[k] = array[j];
                    j = j + 1;    
                }
            } 
        }
        //Copy array
        for(int i = 0; i < n; i++) {
            array[i] = B[i];
        }

    }
}

int search(vector<int> &array, int l, int r, int key) {
   // int l = 0;
   // int r = array.size() - l;
    //while (r >= 1 || l < array.size() - 1) {
    if (r >= l) {
            int mid = l + (r - l) / 2;
        
            if (array[mid] == key) {
                return mid;
            }
        
            if (array[mid] > key) {
                return search(array, l, mid - 1, key);
            }
            
        
            return search(array, mid + 1, r, key);
        //}
    }
    return -1;
}

void checkcopy(vector<int> &array1, vector<int> &array2) {
    int t;
    for (int i = 0; i < array1.size(); i++) {
        
        int s = search(array2, 0, array2.size(), array1[i]);
        
        if (s > 0) {
            
            do {
                t = genrand(0, 1000);
                array2[s] = t;
            } while (search(array1, 0, array1.size(), t) > 0);
        }
    }
}
