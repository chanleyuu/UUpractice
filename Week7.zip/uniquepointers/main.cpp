#include <iostream>
#include <memory>
#include <string>

using namespace std;
int main(int argc, char **argv) {
    
    unique_ptr<int> point (new int(32));
    unique_ptr<int> point2 = std::move(point);
    std::cout << "Value: " << *point2 << " Address: " << &point2 << " " << &*point2 << std::endl;
    
    cout << "Enter a string: " << endl;
    string s;
    cin >> s;
    shared_ptr<string> sharepoint { nullptr };
    *sharepoint = s;
    std::cout << "Value: " << *sharepoint << " Address: " << &sharepoint << " " << &*sharepoint << " " << sharepoint.use_count() << std::endl;
    
    shared_ptr<string> sharepointb { nullptr };
    sharepointb = sharepoint;
    
    std::cout << "Value: " << *sharepointb << " Address: " << &sharepointb << " " << &*sharepointb << " " << sharepointb.use_count() << std::endl;
    return 0;
}
