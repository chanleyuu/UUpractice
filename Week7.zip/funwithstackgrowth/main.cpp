#include <iostream>


void PrintStackArrayAddresses(int* array, int legnth); 
int howmany();
int * createints(int num);
void ReadInts(int* arrayInt, int arrIdx);
int FindMaxInts(int* arrayInt, int arrIdx);

int main(int argc, char **argv)
{
    int len = howmany();
    int* arr = createints(len);
    ReadInts(arr, len);
    PrintStackArrayAddresses(arr, len);
    std::cout << "Max value is: " << FindMaxInts(arr, len) << std::endl;
    
    arr = nullptr;
    delete arr;
    return 0;
}

void PrintStackArrayAddresses(int* array, int legnth) 
{
    int* pointy = &array[0];    
  //  int len = sizeof(*array)/sizeof(int);
   // std::cout << len << std::endl;
    for (int i = 0; i < legnth; i++) {
        std::cout << std::dec << "Value: " << array[i] << " " << "Index:" << i << " " << "Address: " << reinterpret_cast<size_t>(pointy) + i << " ";
        std::cout << std::hex << pointy + i << std::endl;
    }
    pointy = nullptr;
    delete pointy;
    std::cout << std::dec;
}

int howmany() {
    int out;
    std::cout << "How many elements do you want in your array?" << std::endl;
    std::cin >> out;
    return out;
}

int * createints(int num) {
    int * numpoint = new int[num];
    return numpoint;
}

void ReadInts(int* arrayInt, int arrIdx) {
    for (int i = 0; i < arrIdx; i++) {
        std::cout << "Enter a number for the array: " << std::endl;
        std::cin >> arrayInt[i];
     //   std::cout << std::endl;
    }
}

int FindMaxInts(int* arrayInt, int arrIdx) {
    int max = arrayInt[0];
    for (int i = 1; i < arrIdx; i++) {
        if (max < arrayInt[i]) {
            max = arrayInt[i];
        }
    }
    return max;
}
