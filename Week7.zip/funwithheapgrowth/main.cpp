#include <iostream>
#include <random>

void PrintHeapArrayAddresses(float* array, int legnth); 
void SetFloatValues(float* floatArray, int legnth);
float genrand(float min, float max);
int howmany();

int main(int argc, char **argv)
{
    float arr[howmany()];
    int len = sizeof(arr)/sizeof(int);
    SetFloatValues(arr, len);
    PrintHeapArrayAddresses(arr, len);
    std::cout << "Hello, world!" << std::endl;
    return 0;
}

void PrintHeapArrayAddresses(float* array, int legnth) 
{
    float* pointy = &array[0];    
   // int len = legnth;
   // std::cout << len << std::endl; pointy = nullptr;
    for (int i = 0; i < legnth; i++) {
        std::cout << std::dec << "Value: " << array[i] << " " << "Index:" << i << " " << "Address: " << reinterpret_cast<size_t>(pointy) + i << " ";
        std::cout << std::hex << pointy + i << std::endl;
    }
    pointy = nullptr;
    array = nullptr;
    delete pointy;
    delete array;
}

void SetFloatValues(float* floatArray, int legnth) {
        float* pointfloat = nullptr;
        float f = 0.0;
        pointfloat = &f;
        for (int i = 0; i < legnth; i++) {
            *pointfloat = genrand(0.0f, 10000.0f);
            floatArray[i] = *pointfloat;
        }
        pointfloat = nullptr;
        delete pointfloat;
}


float genrand(float min, float max) {
	std::random_device r;
	std::seed_seq seed2{ r(), r(), r(), r(), r(), r(), r(), r() };
	std::mt19937 eng(seed2);
	std::uniform_real_distribution<float> dist(min, max);
	return dist(eng);
}

int howmany() {
    int out;
    std::cout << "How many elements do you want in your array?" << std::endl;
    std::cin >> out;
    return out;
}
